<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

// Timezone
date_default_timezone_set('America/Sao_Paulo');

//Definindo diretorio principal
define('DIRETORIO_PRINCIPAL', '');
define('DIRETORIO_TEMPLATES', 'src/Views/publica');
define('DIRETORIO_TEMPLATES_ADMIN', 'src/Views/admin');
define('URL_BASE', 'http://agenda.soaresdev.com.br'.DIRETORIO_PRINCIPAL.'/');

define('SQL_DB_SERVER', 'localhost');
define('SQL_DB_USER', 'u919145011_agenda');
define('SQL_DB_PASS', 'E94e5678');
define('SQL_DB_DATABASE', 'u919145011_agenda');